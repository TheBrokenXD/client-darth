# Noah will upload the frontend to `main` branch and i will combine it with backend in `dev` branch.

So, For Signup -
```python
from requests import post
post("http://localhost:3000/api/login", {"login": "akash", "secret": "password"})
```

For Login -
```python
from requests import post
post("http://localhost:3000/api/login", {"login": "akash", "secret": "password"})
```

# DAY - 5