function getCookie(cookieName) {
    let name = cookieName + "=";
    let decodedCookie = decodeURIComponent(document.cookie);
    let ca = decodedCookie.split(';');
    for(let i = 0; i <ca.length; i++) {
      let c = ca[i];
      while (c.charAt(0) == ' ') {
        c = c.substring(1);
      }
      if (c.indexOf(name) == 0) {
        return c.substring(name.length, c.length);
      }
    }
    return "";
}

function addToCart(event, productId) {
    event.preventDefault();
    let cart = JSON.parse(localStorage.getItem("cart"));
    if (JSON.parse(localStorage.getItem("cart")).items.toString().includes(productId)) {
        return alert("Product already in cart");
    } else {
        cart.items.push(String(productId));
        alert("Product added to cart");
    }
    localStorage.setItem("cart", JSON.stringify(cart));
}

window.addEventListener('load', async function(event) {
    event.preventDefault();
    let login = getCookie('login');
    let secret = getCookie('secret');
    if (login == '' || secret == '') {
        window.location.href = "/users/signin.html";
    }
});