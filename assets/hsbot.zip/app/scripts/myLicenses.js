function getCookie(cookieName) {
    let name = cookieName + "=";
    let decodedCookie = decodeURIComponent(document.cookie);
    let ca = decodedCookie.split(';');
    for(let i = 0; i <ca.length; i++) {
      let c = ca[i];
      while (c.charAt(0) == ' ') {
        c = c.substring(1);
      }
      if (c.indexOf(name) == 0) {
        return c.substring(name.length, c.length);
      }
    }
    return "";
}

function noLicenses() {
    $(function() {
        $("#noLicensesDialog").dialog({
          resizable: false,
          height: "auto",
          width: "auto",
          modal: true,
          buttons: {
            "OK": function() {
              $( this ).dialog( "close" );
            },
          }
        });
    });
}

async function getBotInfo(id) {
    return await (await axios.get('/bots.json')).data[id];
}

async function downloadAsset(event, botId) {
    event.preventDefault();
    await axios.post('/api/payments', {
        botId: botId,
        action: 'downloadAsset',
        login: getCookie('login'),
        secret: getCookie('secret'),
    });
}

async function updateUI(event) {
    event.preventDefault();
    let hasALicense = false;
    const req = await axios.post('/api/payments', {
        action: 'getTxs',
        login: getCookie('login'),
        secret: getCookie('secret'),
    });
    for (var i of req.data.data.split(';')) {
        if (i == '') return false;
        txnInfo = await axios.post('/api/payments', {
            action: 'getTxInfo',
            login: getCookie('login'),
            secret: getCookie('secret'),
            txId: i,
        });
        if (txnInfo.data.data.amount != txnInfo.data.data.recieved) {
            hasALicense = true;
            for (var bot of txnInfo.data.data.checkout.invoice.split(',')) {
                document.getElementById('myLicensesList').innerHTML += `
                    <div class="Upayments-card">
                        <h4>${(await getBotInfo(bot)).name}</h4>
                        <h3>${txnInfo.data.data.checkout.amountf} ${txnInfo.data.data.checkout.currency}</h3>
                        <h5>Status : ${txnInfo.data.data.status_text}</h5>
                        <h5 style="cursor: pointer;color: var(--color-secondary);" onclick="downloadAsset(event, '${bot}');">Download Asset</h5>
                    </div>
                `;
            }
        }
    }
    if (!hasALicense) {
        noLicenses();
    }
}

window.addEventListener('load', async function(event) {
    event.preventDefault();
    let login = getCookie('login');
    let secret = getCookie('secret');
    if (login == '' || secret == '') {
        window.location.href = "/users/signin.html";
    }
    await updateUI(event);
});