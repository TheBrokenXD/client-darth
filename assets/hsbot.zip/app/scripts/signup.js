function getCookie(cookieName) {
    let name = cookieName + "=";
    let decodedCookie = decodeURIComponent(document.cookie);
    let ca = decodedCookie.split(';');
    for(let i = 0; i <ca.length; i++) {
      let c = ca[i];
      while (c.charAt(0) == ' ') {
        c = c.substring(1);
      }
      if (c.indexOf(name) == 0) {
        return c.substring(name.length, c.length);
      }
    }
    return "";
}

window.addEventListener('load', async function(event) {
    event.preventDefault();
    let login = getCookie('login');
    let secret = getCookie('secret');
    if (login != '' && secret != '') {
        window.location.href = "/users/user.html";
    }
});

async function signUp(event) {
    event.preventDefault();
    const login = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('con-password').value;
    if (password !== confirmPassword) {
        return alert('Password\'s don\'t match');
    }
    const req = await axios.post('/api/signup', {
        login: login,
        secret: password,
    });
    if (req.data.error) {
        if (req.data.message === 'LOGIN_USER_EXISTS') {
            return alert('User with this email already exists !');
        }
        if (req.data.message === 'INTERNAL_ERROR') {
            alert('Please Refresh The Page !');
            return window.location.reload();
        }
    }
    if (req.data.message === 'SIGNUP_SUCCESS') {
        alert('You have successfully signed up !');
    }
    document.cookie = `login=${login}; expires=${new Date(Date.now() + 1000 * 60 * 60 * 24 * 7).toUTCString()};`;
    document.cookie = `secret=${password}; expires=${new Date(Date.now() + 1000 * 60 * 60 * 24 * 7).toUTCString()};`;
    window.location.href = '/';
}
