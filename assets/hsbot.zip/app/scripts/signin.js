function getCookie(cookieName) {
    let name = cookieName + "=";
    let decodedCookie = decodeURIComponent(document.cookie);
    let ca = decodedCookie.split(';');
    for(let i = 0; i <ca.length; i++) {
      let c = ca[i];
      while (c.charAt(0) == ' ') {
        c = c.substring(1);
      }
      if (c.indexOf(name) == 0) {
        return c.substring(name.length, c.length);
      }
    }
    return "";
}

window.addEventListener('load', async function(event) {
    event.preventDefault();
    let login = getCookie('login');
    let secret = getCookie('secret');
    if (login != '' && secret != '') {
        window.location.href = "../users/user.html";
    }
});

async function signIn(event) {
    event.preventDefault();
    const login = document.getElementById('email').value;
    const secret = document.getElementById('password').value;
    if (!login || !secret) {
        alert('Invalid Email or Password !');
        return;
    }
    const req = await axios.post('/api/login', {
        login: login,
        secret: secret,
    });
    if (req.data.error) {
        if (req.data.message === 'LOGIN_USER_NOT_FOUND') {
            return alert('Please SignUp First !');
        }
        if (req.data.message === 'LOGIN_PASSWORD_WRONG') {
            alert('Invalid Creditentals !');
            return window.location.reload();
        }
    }
    if (req.data.message === 'AUTHENTICATION_SUCCESSFULL') {
        alert('You have successfully signed in !');
    }
    document.cookie = `login=${login}; expires=${new Date(Date.now() + 1000 * 60 * 60 * 24 * 7).toUTCString()};`;
    document.cookie = `secret=${secret}; expires=${new Date(Date.now() + 1000 * 60 * 60 * 24 * 7).toUTCString()};`;
    window.location.href = '/';
}
