function getCookie(cookieName) {
    let name = cookieName + "=";
    let decodedCookie = decodeURIComponent(document.cookie);
    let ca = decodedCookie.split(';');
    for(let i = 0; i <ca.length; i++) {
      let c = ca[i];
      while (c.charAt(0) == ' ') {
        c = c.substring(1);
      }
      if (c.indexOf(name) == 0) {
        return c.substring(name.length, c.length);
      }
    }
    return "";
}

function deleteAllCookies(event) {
    event.preventDefault();
    var allCookies = document.cookie.split(';');
    for (var i = 0; i < allCookies.length; i++) {
        document.cookie = allCookies[i] + "=;expires=" + new Date(0).toUTCString() + ";path=/";
    }
    window.location.reload();
}

async function getBotInfo(id) {
    return await (await axios.get('/bots.json')).data[id];
}

async function getMyTxs(event) {
    event.preventDefault();
    const req = await axios.post('/api/payments', {
        action: 'getTxs',
        login: getCookie('login'),
        secret: getCookie('secret'),
    });
    console.log(req.data);
    var tabledata = [];
    var index = 1;
    for (var i of req.data.data.split(';')) {
        tabledata.push({ index: index, transactionId: i, });
    }
    new Tabulator(".txsTable", {
        height: 205,
        data: tabledata,
        layout: "fitColumns",
        columns: [
            { title: "Index", field: "index", },
            { title: "Transaction Id", field: "transactionId", hozAlign: "left", },
        ],
   });
   document.querySelector('.txsTable').classList.toggle('hide');
   document.querySelector('.accountInfo').classList.toggle('hide');
}

async function getAccountInfo(event) {
    event.preventDefault();
    const accountInfo = await axios.post('/api/accountInfo', {
        login: getCookie('login'),
        secret: getCookie('secret'),
    });
    document.getElementById('email').value = accountInfo.data.data.login;
    document.getElementById('secret').value = accountInfo.data.data.password;
    document.getElementById('firstappeardate').value = new Date(accountInfo.data.data.firstappeardate).toLocaleString();
}

async function getMePayments(event) {
    event.preventDefault();
    const req = await axios.post('/api/payments', {
        action: 'getTxs',
        login: getCookie('login'),
        secret: getCookie('secret'),
    });
    let index = 1;
    for (var i of req.data.data.split(';')) {
        if (i == '') return false;
        txnInfo = await axios.post('/api/payments', {
            action: 'getTxInfo',
            login: getCookie('login'),
            secret: getCookie('secret'),
            txId: i,
        });
        document.getElementById('mePayments').innerHTML += `
            <div class="Upayments-card">
                <h4>${(await getBotInfo(txnInfo.data.data.checkout.invoice.split(',')[0])).name} ...</h4>
                <h3>${txnInfo.data.data.checkout.amountf} ${txnInfo.data.data.checkout.currency}</h3>
                <h5>Status : ${txnInfo.data.data.status_text}</h5>
            </div>
        `;
        if (txnInfo.data.data.amount == txnInfo.data.data.recieved) {
            document.getElementById('successfulTxs').innerHTML += `
            <div class="transaction-${index}">
                <p>${(await getBotInfo(txnInfo.data.data.checkout.invoice.split(',')[0])).name}</p>
                <p>${txnInfo.data.data.checkout.amountf} ${txnInfo.data.data.checkout.currency}</p>
                <a style="cursor: pointer;" onclick="getLicenses(event);">Get License</a>
            </div>`;
        }
        index++;
    }
    if (req.data.data.split(';').length == 2 && req.data.data.split(';')[0] == '' && req.data.data.split(';')[1] == '') {
        document.getElementById('mePayments').innerHTML += `
            <div class="Upayments-card">
                <h4>No Payments</h4>
                <h3>No Recent Payments</h3>
                <h5>Status : Empty</h5>
            </div>
        `;
        return false;
    }
}

function getLicenses(event) {
    event.preventDefault();
    window.location.href = '/users/myLicenses.html';
}

window.addEventListener('load', async function(event) {
    event.preventDefault();
    let login = getCookie('login');
    let secret = getCookie('secret');
    if (login == '' || secret == '') {
        window.location.href = "/users/signin.html";
    }
    await getAccountInfo(event);
    await getMePayments(event);
});